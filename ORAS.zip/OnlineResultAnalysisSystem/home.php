<?php
session_start();
$name=$_SESSION['username'];
$sql="select * from `teacher` t, `department` d where t.`ssn`='$name' and d.`hodssn`='$name'";
$query=mysql_query($sql);
echo mysql_num_rows($query);
// for($i=0;$i<mysql_num_rows($query);$i++) {
	// if($name==mysql_result($query, $i, 'hodssn')){
		// break;
		
	// }
// }
if($name=='admin') {
	header('Location:profileAdmin.php');
} else if($name=='coe') {
	header('Location:profileCOE.php');
} else if($name[0]=='2' and ($name[1]=='S' or $name[1]=='s')) {
	header('Location:profileStudent.php');
} else if(mysql_num_rows($query)==1){
	header('Location:profileHOD.php');
} else {
	header('Location:profileTeacher.php');
}
?>