<?php

//include("../includes/notifyReadHandler.php");

?>

<!DOCTYPE html>
<!--[if lt IE 7]>       <html class="no-js lt-ie9 lt-ie8 lt-ie7">   <![endif]-->
<!--[if IE 7]>          <html class="no-js lt-ie9 lt-ie8">          <![endif]-->
<!--[if IE 8]>          <html class="no-js lt-ie9">                 <![endif]-->
<!--[if gt IE 8]><!-->  <html class="no-js">                        <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Chromosis ERP</title>
        <meta name="description" content="Chromosis Admin Theme">
        <meta name="viewport" content="width=device-width">
        <link type="text/css" rel="stylesheet" href="../assets/css/bootstrap.css">
        <link type="text/css" rel="stylesheet" href="../assets/css/bootstrap-responsive.min.css">
            <link type="text/css" rel="stylesheet" href="../assets/Font-awesome/css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="../assets/font-awesome-4.1.0/css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="../assets/css/style.css">
        <link type="text/css" rel="stylesheet" href="../assets/css/styles.css">
        <link type="text/css" rel="stylesheet" href="../assets/css/calendar.css">
		<link type="text/css" rel="stylesheet" href="../assets/css/DT_bootstrap.css"/>
        <link rel="stylesheet" href="../assets/css/responsive-tables.css">
		
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="../assets/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>



        <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
        <script>window.jQuery.ui || document.write('<script src="../assets/js/vendor/jquery-ui-1.10.0.custom.min.js"><\/script>')</script>
		<script src="../assets/js/lib/bootstrap-datepicker.js"></script>
		<link rel="stylesheet" href="../assets/css/datepicker.css">
		
        <link rel="stylesheet" href="../assets/css/theme.css">
        <link rel="stylesheet" href="../notifications/lightbox_info_msg.css" type="text/css" media="screen" />
		<script type='text/javascript' src='../notifications/infoMessageDisplayJS.js'></script>

        <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
        <!--[if IE 7]>
        <link type="text/css" rel="stylesheet" href="assets/Font-awesome/css/font-awesome-ie7.min.css"/>
        <![endif]-->

        <script src="../assets/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
		
		<script type='text/javascript' src='../javascripts/notification.js'></script>
		<script type='text/javascript' src='../javascripts/changeWareHouse.js'></script>




<script type='text/javascript'>
function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
       window.onload = func
    } else {
       window.onload = function() {
           if (oldonload) {
                  oldonload()
          }
          func()
       }
   }
} 

addLoadEvent(function() {
	displayDivScript();
	if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
		document.getElementById("left").style.position = 'static';
	}
	 var ajaxURL = "../notifications/notificationAjax.php?LEVEL=1";
					notf(ajaxURL);
					//setInterval(function() { notf(ajaxURL) }, 5000);
					
	
	
	<?php
	
	include("onLoadHandler.php");
	
	
	?>
});
</script>