<?php
    (mysql_connect('localhost', 'root', '') and mysql_select_db('resultmanagement')) or die();
?>
<meta name="viewport" content="width=device-width">
<link type="text/css" rel="stylesheet" href="bootstrap.css">
<link type="text/css" rel="stylesheet" href="bootstrap.min.css">
<link type="text/css" rel="stylesheet" href="font-awesome.min.css">
<!--<link type="text/css" rel="stylesheet" href="style.css">-->
<link type="text/css" rel="stylesheet" href="styles.css">
<link type="text/css" rel="stylesheet" href="style-large.css">
<link type="text/css" rel="stylesheet" href="dashboard.css"/>
<link type="text/css" rel="stylesheet" href="mystyle.css">
<link type="text/css" rel="stylesheet" href="mystyle.css">
<link type="text/css" rel="stylesheet" href="bootstrap-theme.min.css">
<link type="text/css" rel="stylesheet" href="bootstrap-theme.css">
<link type="text/css" rel="stylesheet" href="style-medium.css">
<link type="text/css" rel="stylesheet" href="style-small.css">
<link type="text/css" rel="stylesheet" href="style-small.css">
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="jquery-1.11.3.js"></script>
<script type="text/javascript" src="jquery.validate.min.js"></script>
<script type="text/javascript" src="bootstrap.js"></script>
<script type="text/javascript" src="bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap.min.js"></script>
