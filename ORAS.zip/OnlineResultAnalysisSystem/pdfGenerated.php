<?php
require('C:\xampp\htdocs\FPDF\fpdf.php');
session_start();
$name=$_SESSION['name'];
$username=$_SESSION['username'];
$semester=$_POST['semester'];
if(mysql_connect('localhost', 'root') and mysql_select_db('resultmanagement')){
		$sql= "select `department_deptid` from `student` where `usn`='$username'";
		if($query_run=mysql_query($sql))
		{
			$deptid=mysql_result($query_run, 0, 'department_deptid');
		}else	{die('error');}
}	
$sql= "select `deptname` from `department` where `deptid`='$deptid'";
if($query_run=mysql_query($sql))
{
	$deptname=mysql_result($query_run, 0, 'deptname');
	//echo $deptname;
}else	{die('error');}
$deptname.=' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.' ';
$branch=$deptname;
if($semester%2==0)
$month='June';
else
$month='Jan';
$sql= "select distinct `year` as `x` from `perceives` where `student_usn`='$username' and `sem`='$semester'";
if($query_run=mysql_query($sql))
{
	$date=mysql_result($query_run, 0, 'x');$date=$date[0].$date[1].$date[2].$date[3];
}else	{die('error');}

//$year=$date[0].$date[1].$date[2].$date[3];
$sql = "select format(sum(c.credits),2) as `result` from course c, perceives p where p.student_usn='$username' and p.course_course_id=c.course_id and p.sem='$semester'";
if($query_run=mysql_query($sql))
{
	$credits=mysql_result($query_run, 0, 0);
	
	//echo $credits.'ssssssss';
}else	{echo 'error';//die('error1');
}
$sgpa=9.00;
$cgpa=9.00;
$earned_credits=23;
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Times','B',14);
$pdf->Cell(0,10,'				SHRI DHARMASTALA MANJUNATHESHWARA COLLEGE OF ', 0, 1, 'C');
$pdf->Cell(0,8,'				ENGINEERING & TECHNOLOGY, Dhavalagiri, DHARWAD - 580 002', 0, 1, 'C');
$pdf->SetFont('Times','B',10);
$pdf->Cell(0,10,'(Autonomous Institution under Vishweshwarayya Technological University, Belgaum Recognized by AICTE, New Delhi)', 0,1,'C');
$pdf->SetFont('Times','U',18);
$pdf->Cell(0,20	,'Provisional Grade Sheet', 0, 1, 'C');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20,10,'Name: ', 0, 0, 'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(60,10,$name, 0, 0 );
$pdf->SetFont('Times','B',14);
$pdf->Cell(150,10,'USN: ', 0, 0, 'C');
$pdf->SetFont('Times','',14);
$pdf->Cell(0,10,' '.$username, 0, 1, 'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20, 10, 'Branch: ', 0,0,'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(71.5, 10, $branch, 0,0,'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(80, 10, 'Semester: ', 0,0,'R');
$pdf->SetFont('Times','',14);
$pdf->Cell(4, 10, $semester, 0,1,'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20, 10, 'Examination: ', 0,0,'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(43, 10, $month.'/ '.$date, 0,1,'C');
$pdf->Cell(0,10, '', 0,1,'C');
$pdf->Cell(18,20, 'Sl.No', 1,0,'C');
$pdf->Cell(105,20, 'Subjects', 1,0,'C');
$pdf->Cell(23,20, 'Sub. Code', 1,0,'C');
$pdf->Cell(23,20, 'Credits', 1,0,'C');
$pdf->Cell(23,20, 'Grades', 1,1,'C');
$sql="select `grade`, `course_course_id` from perceives where student_usn='$username' and sem='$semester'";
$query_run=mysql_query($sql);
$rows=mysql_num_rows($query_run);
for($i=0;$i<$rows; $i++)
{
	$grade[$i]=mysql_result($query_run, $i, 'grade');
	$course_id[$i]=mysql_result($query_run, $i, 'course_course_id');
	$assign=$course_id[$i];
	$sql1 = "SELECT `name`, `credits` FROM `course` WHERE `course_id`='$assign'";
	$sql1_run=mysql_query($sql1);
	$course_name[$i]=mysql_result($sql1_run, 0,'name');
	$assigned_Credits[$i]=mysql_result($sql1_run, 0,'credits');
}
$grades='A';
for($i=0; $i<$rows; $i++)
{
	$pdf->Cell(18,8,$i,1,0, 'C');
	$pdf->Cell(105,8,$course_name[$i],1,0, 'C');
	$pdf->Cell(23,8,$course_id[$i],1,0, 'C');
	$pdf->Cell(23,8,$assigned_Credits[$i],1,0, 'C');
	$pdf->Cell(23,8,$grades,1,1, 'C');
}
	
//for($t=0,$i=0;$i<(mysql_num_rows($query_run)*5);$t++)
//{
	
//}
//for($p=4;$p<45;$p=$p+5)
//{$table_data[$p]='A';}
//$k=0;
/*for($j=0; $j<9; $j++,$k++){
for($i=0; $i<4;$i++,$k++)
{
	if($i==1)
	{
	$pdf->Cell(77,8,$table_data[$k],1,0, 'C');
	}
	else{
    $pdf->Cell(27,8,$table_data[$k],1,0,'C');
	}
}
     $pdf->Cell(27,8,$table_data[$k],1,1,'C');
	 //$k=0;
}*/
$pdf->Cell(0,10, '', 0,1,'C');
$pdf->Cell(70,10, 'Total Credits: ', 0,0,'R');
$pdf->Cell(10,10, $credits, 0,0,'R');
$pdf->Cell(60,10, 'SGPA: ', 0,0,'R');
$pdf->Cell(10,10,$sgpa, 0,1,'R');
$pdf->Cell(70,10, 'Credits Earned: ', 0,0,'R');
$pdf->Cell(10,10, $earned_credits, 0,1,'R');
$pdf->SetXY(($pdf->getX()+35),$pdf->getY());
$pdf->Cell(20,70, 'Signature of the COE', 0,0,'R');
$pdf->Cell(130,70, 'Signature of the Principal', 0,0,'R');
$pdf->Image('logo.png', 12, 10, 15, 15, 'PNG');
$pdf->Line(10, 40, 200, 40);
$pdf->Output();
?>