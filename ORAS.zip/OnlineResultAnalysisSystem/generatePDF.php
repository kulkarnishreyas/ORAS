<?php
require('C:\xampp\htdocs\FPDF\fpdf.php');
$name='Adithya';
$usn='2sd12cs096';
$branch='Computer Science and Engineering';
$sem='III';
$month='June';
$year='2014-15';
$credits=23;
$sgpa=8.08;
$cgpa=7.52;
$earned_credits=23;
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Times','B',14);
$pdf->Cell(0,10,'SHRI DHARMASTALA MANJUNATHESHWARA COLLEGE OF ENGINEERING &', 0, 1, 'C');
$pdf->Cell(0,8,'TECHNOLOGY, Dhavalagiri, DHARWAD - 580 002', 0, 1, 'C');
$pdf->SetFont('Times','B',10);
$pdf->Cell(0,10,'(Autonomous Institution under Vishweshwarayya Technological University, Belgaum Recognized by AICTE, New Delhi)', 0,1,'C');
$pdf->SetFont('Times','U',18);
$pdf->Cell(0,20	,'Provisional Grade Sheet', 0, 1, 'C');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20,10,'Name: ', 0, 0, 'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(60,10,$name, 0, 0 );
$pdf->SetFont('Times','B',14);
$pdf->Cell(160,10,'USN: ', 0, 0, 'C');
$pdf->SetFont('Times','',14);
$pdf->Cell(0,10,' '.$usn, 0, 1, 'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20, 10, 'Branch: ', 0,0,'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(71.5, 10, $branch, 0,0,'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(85, 10, 'Semester: ', 0,0,'R');
$pdf->SetFont('Times','',14);
$pdf->Cell(8, 10, $sem, 0,1,'R');
$pdf->SetFont('Times','B',14);
$pdf->Cell(20, 10, 'Examination: ', 0,0,'L');
$pdf->SetFont('Times','',14);
$pdf->Cell(60, 10, $month.'/'.$year, 0,1,'C');
$pdf->Cell(0,10, '', 0,1,'C');
$pdf->Cell(27,20, 'Sl.No', 1,0,'C');
$pdf->Cell(77,20, 'Subjects', 1,0,'C');
$pdf->Cell(27,20, 'Sub. Code', 1,0,'C');
$pdf->Cell(27,20, 'Credits', 1,0,'C');
$pdf->Cell(27,20, 'Grades', 1,1,'C');
for($t=0,$i=0;$i<=45;$t++)
{
	$table_data[$i++]=($t+1).'';
	$table_data[$i++]='S'.($t+1);
	$table_data[$i++]='CS'.(350+$t);
	$table_data[$i++]=4;
	//echo $table_data[3];
	$tabel_data[$i++]='A';
	//echo $table_data[4];
	//echo $table_data[4];
}
for($p=4;$p<45;$p=$p+5)
{$table_data[$p]='A';}
$k=0;
for($j=0; $j<9; $j++,$k++){
for($i=0; $i<4;$i++,$k++)
{
	if($i==1)
	{
	$pdf->Cell(77,8,$table_data[$k],1,0, 'C');
	}
	else{
    $pdf->Cell(27,8,$table_data[$k],1,0,'C');
	}
}
     $pdf->Cell(27,8,$table_data[$k],1,1,'C');
	 //$k=0;
}
$pdf->Cell(0,10, '', 0,1,'C');
$pdf->Cell(70,10, 'Total Credits: ', 0,0,'R');
$pdf->Cell(10,10, $credits, 0,0,'R');
$pdf->Cell(60,10, 'SGPA: ', 0,0,'R');
$pdf->Cell(10,10,$sgpa, 0,1,'R');
$pdf->Cell(70,10, 'Credits Earned: ', 0,0,'R');
$pdf->Cell(10,10, $earned_credits, 0,0,'R');
$pdf->Cell(60,10, 'CGPA: ', 0,0,'R');
$pdf->Cell(10,10, $cgpa, 0,1,'R');
$pdf->Output();
?>